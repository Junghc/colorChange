//
//  ViewController.swift
//  colorChange
//
//  Created by User12 on 2018/11/6.
//  Copyright © 2018 User12. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    @IBOutlet weak var grView: UIView!
    @IBOutlet weak var redSlider: UISlider!
    
    @IBOutlet weak var greenSlider: UISlider!
    
    @IBOutlet weak var blueSlider: UISlider!
    
    @IBOutlet weak var alphaSlider: UISlider!
    @IBOutlet weak var grSlider: UISlider!
    @IBOutlet weak var colorPic: UIImageView!
    @IBAction func colorChange(_ sender: Any) {
        colorPic.backgroundColor =  UIColor(red: CGFloat(redSlider.value), green: CGFloat(greenSlider.value), blue: CGFloat(blueSlider.value), alpha:  CGFloat(alphaSlider.value))
    }
    
  
    @IBAction func grChange(_ sender: UISlider) {
        let gradientLayer = CAGradientLayer()
        let locationTop = round(10*grSlider.value)/10
        gradientLayer.colors = [UIColor.yellow.cgColor, UIColor.red.cgColor,UIColor.blue.cgColor,UIColor.orange.cgColor]
        gradientLayer.frame = self.grView.bounds
        gradientLayer.locations = [0.0,NSNumber(value: locationTop)]
        self.grView.layer.addSublayer(gradientLayer)
    }
    
}

